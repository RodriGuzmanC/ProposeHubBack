<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($plantilla->nombre); ?></title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
</head>
<body>
    <div id="content">
        <h1><?php echo e($plantilla->nombre); ?></h1>
        <?php echo $plantilla->contenido; ?>

    </div>
    <button id="download-pdf">Descargar PDF</button>

    <script>
        document.getElementById('download-pdf').addEventListener('click', function() {
            const element = document.getElementById('content');
            html2pdf()
                .from(element)
                .save(`plantilla_<?php echo e($plantilla->id); ?>.pdf`);
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Proposal_HUB\resources\views/dashboard/plantillas/download.blade.php ENDPATH**/ ?>