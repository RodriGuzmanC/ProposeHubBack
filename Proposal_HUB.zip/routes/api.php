<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ClienteController;
use App\Http\Controllers\Api\OrganizacionController;
use App\Http\Controllers\Api\ServicioController;
use App\Http\Controllers\Api\PropuestaController;
use App\Http\Controllers\Api\UsuarioController;
use App\Http\Controllers\Api\PlantillaController;
use App\Http\Controllers\Api\VersionPropuestaController;
use App\Http\Controllers\Api\MailController;
use App\Http\Controllers\API\RolController;
use App\Http\Controllers\API\ImageController;
use App\Http\Controllers\API\PdfController;
use App\Http\Controllers\API\RecuperacionContrasenasController;

//rutas clientes
Route::get('clientes', [ClienteController::class, 'obtenerTodos']);
Route::get('clientes/{id}', [ClienteController::class, 'obtenerUno']);
Route::post('clientes', [ClienteController::class, 'crear']);
Route::post('clientes/login', [ClienteController::class, 'login']);
Route::put('clientes/{id}', [ClienteController::class, 'editar']);
Route::delete('clientes/{id}', [ClienteController::class, 'eliminar']);

//rutas organizaciones
Route::get('organizaciones', [OrganizacionController::class, 'obtenerTodos']);
Route::get('organizaciones/{id}', [OrganizacionController::class, 'obtenerUno']);
Route::post('organizaciones', [OrganizacionController::class, 'crear']);
Route::put('organizaciones/{id}', [OrganizacionController::class, 'editar']);
Route::delete('organizaciones/{id}', [OrganizacionController::class, 'eliminar']);

//rutas propuestas
Route::get('propuestas', [PropuestaController::class, 'obtenerTodos']);
Route::get('propuestas/{id}', [PropuestaController::class, 'obtenerUno']);
Route::post('propuestas', [PropuestaController::class, 'crear']);
Route::put('propuestas/{id}', [PropuestaController::class, 'editar']);
Route::delete('propuestas/{id}', [PropuestaController::class, 'eliminar']);
Route::post('propuestas/respuesta-ai', [PropuestaController::class, 'respuestaAI']);


//rutas usuarios
Route::post('register', [UsuarioController::class, 'register']);
Route::post('login', [UsuarioController::class, 'login']);
Route::post('logout', [UsuarioController::class, 'logout']);

Route::get('usuarios', [UsuarioController::class, 'index']); // Obtener todos los usuarios
Route::get('usuarios/{id}', [UsuarioController::class, 'show']); // Obtener un usuario
Route::put('usuarios/{id}', [UsuarioController::class, 'update']); // Actualizar un usuario
Route::put('usuarios/cambiar-clave/{id}', [UsuarioController::class, 'cambiarClave']); // Actualizar un usuario
Route::delete('usuarios/{id}', [UsuarioController::class, 'destroy']); // Eliminar un usuario


Route::get('recuperar-contrasena/{token}', [RecuperacionContrasenasController::class, 'obtenerToken']); 
Route::post('recuperar-contrasena/regenerar/', [RecuperacionContrasenasController::class, 'regenerarToken']);
Route::post('recuperar-contrasena/resetear/', [RecuperacionContrasenasController::class, 'cambiarContrasena']);

//rutas plantillas
Route::get('plantillas/', [PlantillaController::class, 'obtenerTodos']);
Route::get('plantillas/{id}', [PlantillaController::class, 'obtenerUno']);
Route::get('plantillas/contenido/{id}', [PlantillaController::class, 'obtenerContenido']);
Route::put('plantillas/contenido/{id}', [PlantillaController::class, 'editarContenido']);

Route::post('plantillas/', [PlantillaController::class, 'crear']);
Route::put('plantillas/{id}', [PlantillaController::class, 'editar']);
Route::delete('plantillas/{id}', [PlantillaController::class, 'eliminar']);


//rutas usuarios


//rutas servicios
Route::get('servicios', [ServicioController::class, 'obtenerTodos']);
Route::get('servicios/{id}', [ServicioController::class, 'obtenerUno']);
Route::post('servicios', [ServicioController::class, 'crear']);
Route::put('servicios/{id}', [ServicioController::class, 'editar']);
Route::delete('servicios/{id}', [ServicioController::class, 'eliminar']);

//rutas versiones propuestas
Route::get('versiones-propuesta/{id}', [VersionPropuestaController::class, 'obtenerTodos']); // Obtiene las versiones de una propuesta, id es de la propuesta
Route::get('version-propuesta/{id}', [VersionPropuestaController::class, 'obtenerUno']);
Route::post('version-propuesta', [VersionPropuestaController::class, 'crear']);
Route::put('version-propuesta/{id}', [VersionPropuestaController::class, 'editar']);
Route::get('version-propuesta/en-edicion/{id}', [VersionPropuestaController::class, 'obtenerVersionEnEdicion']); // id de la propuesta
Route::put('version-propuesta/en-edicion/{id}', [VersionPropuestaController::class, 'cambiarEstadoVersion']); // id de la propuesta

Route::get('version-propuesta/publicada/{id}', [VersionPropuestaController::class, 'obtenerVersionPublicada']); // id de la propuesta


//ruta para subir imagenes
Route::post('imagenes/', [ImageController::class, 'store']);
Route::get('imagenes/buscar/{nombre}', [ImageController::class, 'search']);
Route::get('imagenes/', [ImageController::class, 'load']);



//rutas roles
Route::get('roles', [RolController::class, 'obtenerTodos']);
Route::get('roles/{id}', [RolController::class, 'obtenerUno']);
Route::post('roles', [RolController::class, 'crear']);
Route::put('roles/{id}', [RolController::class, 'editar']);
Route::delete('roles/{id}', [RolController::class, 'eliminar']);

// Ruta para envio de correos
Route::post('/enviar-correo', [MailController::class, 'sendEmail']);

// Ruta de generacion pdf
Route::post('generar-pdf', [PdfController::class, 'generatePdf']);


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
