<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clientes', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->string('correo')->nullable();
            $table->string('telefono', 20)->nullable();
            $table->foreignId('id_organizacion');
            $table->timestamps(0); // crea created_at y updated_at sin decimales
            $table->text('contrasena_hash')->nullable();

            // Definir la clave foránea
            $table->foreign('id_organizacion')
                  ->references('id')
                  ->on('organizaciones')
                  ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clientes');
    }
}
