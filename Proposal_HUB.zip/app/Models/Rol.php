<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rol extends Model
{
    use HasFactory;

    protected $table = 'rol'; // Especificar la tabla

    protected $fillable = [
        'nombre',
        'descripcion',
    ];
    public $timestamps = false;
}
